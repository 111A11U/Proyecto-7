import { useParams } from "react-router-dom";

const Detail = () => {
  let { nombre } = useParams();
  let { imagen } = useParams();
  let { altura } = useParams();
  let { dimensiones } = useParams();
  let { material } = useParams();
  let { color } = useParams();
  let { linea } = useParams();

  return (
    <>
      <div>
        <h2>Este es el robot {nombre}</h2>
        <img
          src={require(`../images/${imagen}.jpg`)}
          alt={"foto de" + nombre}
        />
        <p>Altura {altura}</p>
        <p>Dimensiones {dimensiones}</p>
        <p>Material {material}</p>
        <p>Color {color}</p>
        <p>Línea {linea}</p>
      </div>
    </>
  );
};

export default Detail;
