import Item from "./Items";
import "../stylesheets/Listado.css";

const Listado = () => {
  return (
    <div className="imagen-listado">
      <div className="app-listado">
        <h1>MECHAS BATTLE FOR THE STARS</h1>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
      </div>
      <br/>
      <div className="contenedor-listado">
        <Item
          nombre="Tyrant Mecha 01"
          imagen="m01"
          imagen2="caution"
          imagen3="m01"
          escala="1-18 pulg."
          dimensiones="12.99 pulg. - 33cm"
          material="Polipropileno ABS PVC"
          color="White Olive"
          linea="Battle for the Stars"
        />
        <Item
          nombre="New Zeus Mecha 02"
          imagen="m02"
          imagen2="caution"
          imagen3="m02"
          escala="1-18 pulg."
          dimensiones="12.6 pulg. - 32cm"
          material="Polipropileno ABS PVC"
          color="Python green"
          linea="Battle for the Stars"
        />
        <Item
          nombre="Fear VI Mecha 09"
          imagen="m03"
          imagen2="caution"
          imagen3="m03"
          escala="1-18 pulg."
          dimensiones="12.6 pulg. - 32cm"
          material="Polipropileno ABS PVC"
          color="Warfare"
          linea="Battle for the Stars"
        />
        <Item
          nombre="Fear V Mecha 09"
          imagen="m04"
          imagen2="caution"
          imagen3="m04"
          escala="1-18 pulg."
          dimensiones="12.6 pulg. - 32cm"
          material="Polipropileno ABS PVC"
          color="Airborne gray"
          linea="Battle for the Stars"
        />
        <Item
          nombre="Tiekui Dual Mecha 01"
          imagen="m05"
          imagen2="caution"
          imagen3="m05"
          escala="1-18 pulg."
          dimensiones="12.99 pulg. - 33cm"
          material="Polipropileno ABS PVC"
          color="Pitch Black"
          linea="Battle for the Stars"
        />
        <Item
          nombre="Snarch Commando Mecha 13"
          imagen="m06"
          imagen2="caution"
          imagen3="m06"
          escala="1-18 pulg."
          dimensiones="12.6 pulg. - 32cm"
          material="Polipropileno ABS PVC"
          color="Decoy"
          linea="Battle for the Stars"
        />
      </div>
    </div>
  );
};
export default Listado;
